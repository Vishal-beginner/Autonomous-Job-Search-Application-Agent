import React from 'react';

export default function Profile({ profile, setProfile, resume, setResume, saved, onSave }) {
  const update = (field, value) => setProfile((p) => ({ ...p, [field]: value }));

  return (
    <>
      {/* Personal Info */}
      <div className="C">
        <div className="Ch">
          <div className="ic">👤</div>
          <h2>Your Details</h2>
          {saved && (
            <span className="saved-badge">✓ SAVED</span>
          )}
        </div>
        <div className="G">
          <div className="F">
            <label className="L">Full Name</label>
            <input className="I" placeholder="Jane Doe" value={profile.fullName} onChange={(e) => update('fullName', e.target.value)} />
          </div>
          <div className="F">
            <label className="L">Email</label>
            <input className="I" type="email" placeholder="jane@example.com" value={profile.email} onChange={(e) => update('email', e.target.value)} />
          </div>
          <div className="F">
            <label className="L">Phone</label>
            <input className="I" placeholder="+1 555-000-0000" value={profile.phone} onChange={(e) => update('phone', e.target.value)} />
          </div>
          <div className="F">
            <label className="L">Portfolio</label>
            <input className="I" placeholder="https://yoursite.dev" value={profile.portfolio} onChange={(e) => update('portfolio', e.target.value)} />
          </div>
          <div className="F w">
            <label className="L">Professional Summary</label>
            <textarea className="I" placeholder="Brief summary of your experience, skills, and goals..." value={profile.summary} onChange={(e) => update('summary', e.target.value)} />
          </div>
        </div>
      </div>

      {/* Profile Links */}
      <div className="C">
        <div className="Ch">
          <div className="ic">🔗</div>
          <h2>Profile Links</h2>
        </div>
        <div className="G">
          <div className="F">
            <label className="L">LinkedIn</label>
            <input className="I" placeholder="https://linkedin.com/in/you" value={profile.linkedin} onChange={(e) => update('linkedin', e.target.value)} />
          </div>
          <div className="F">
            <label className="L">GitHub</label>
            <input className="I" placeholder="https://github.com/you" value={profile.github} onChange={(e) => update('github', e.target.value)} />
          </div>
          <div className="F">
            <label className="L">LeetCode</label>
            <input className="I" placeholder="https://leetcode.com/you" value={profile.leetcode} onChange={(e) => update('leetcode', e.target.value)} />
          </div>
        </div>
      </div>

      {/* Resume */}
      <div className="C">
        <div className="Ch">
          <div className="ic">📄</div>
          <h2>Resume</h2>
        </div>
        <div className="F">
          <label className="L">Paste resume text (skills, experience, education)</label>
          <textarea
            className="I"
            style={{ minHeight: 120 }}
            placeholder={
              'Skills: React, Python, AWS...\nExperience: 3 years at XYZ Corp...\nEducation: B.Tech CS...'
            }
            value={resume}
            onChange={(e) => setResume(e.target.value)}
          />
        </div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
        <button className="B Bp" onClick={onSave}>✓ Save Profile</button>
      </div>
    </>
  );
}
