import React, { useState } from 'react';
import { PROVIDERS } from '../utils/constants';

export default function Settings({ provider, setProvider, model, setModel, apiKeys, setApiKey }) {
  const [keyVis, setKeyVis] = useState({});
  const P = PROVIDERS[provider];

  const pickProvider = (pid) => {
    setProvider(pid);
    setModel(PROVIDERS[pid].models[0].id);
  };

  return (
    <>
      {/* Provider Selection */}
      <div className="C">
        <div className="Ch">
          <div className="ic">🤖</div>
          <h2>AI Provider</h2>
        </div>
        <p style={{ color: 'var(--t2)', fontSize: 13, marginBottom: 12 }}>
          All providers require an API key when running as a standalone app.
          Get your key from the provider's platform.
        </p>
        <div className="PR">
          {Object.entries(PROVIDERS).map(([id, p]) => (
            <div
              key={id}
              className={`PC ${provider === id ? 'on' : ''}`}
              onClick={() => pickProvider(id)}
            >
              <span style={{ color: p.color, fontSize: 16 }}>{p.icon}</span>
              <span>{p.name}</span>
            </div>
          ))}
        </div>
        <div className="F" style={{ marginTop: 8 }}>
          <label className="L">Model</label>
          <select className="I" value={model} onChange={(e) => setModel(e.target.value)}>
            {P.models.map((m) => (
              <option key={m.id} value={m.id}>{m.label}</option>
            ))}
          </select>
        </div>
      </div>

      {/* API Keys */}
      <div className="C">
        <div className="Ch">
          <div className="ic">🔑</div>
          <h2>API Keys</h2>
        </div>
        <p style={{ color: 'var(--t2)', fontSize: 12.5, marginBottom: 14, lineHeight: 1.5 }}>
          Keys are stored in your browser's localStorage and sent only to their respective provider endpoint.
          They never leave your machine otherwise.
        </p>
        {Object.entries(PROVIDERS).map(([id, p]) => (
          <div key={id} style={{ marginBottom: 14 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
              <span style={{ color: p.color }}>{p.icon}</span>
              <span style={{ fontWeight: 600, fontSize: 13 }}>{p.name}</span>
              {apiKeys[id] && (
                <span style={{ color: 'var(--ok)', fontSize: 10, fontFamily: 'var(--fm)' }}>
                  ✓ SET
                </span>
              )}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <input
                className="I"
                style={{ flex: 1 }}
                type={keyVis[id] ? 'text' : 'password'}
                placeholder={p.placeholder}
                value={apiKeys[id] || ''}
                onChange={(e) => setApiKey(id, e.target.value)}
              />
              <button
                className="B Bs Bsm"
                onClick={() => setKeyVis((v) => ({ ...v, [id]: !v[id] }))}
              >
                {keyVis[id] ? 'Hide' : 'Show'}
              </button>
              <a
                href={p.docs}
                target="_blank"
                rel="noopener noreferrer"
                className="B Bs Bsm"
                style={{ textDecoration: 'none' }}
              >
                Get Key
              </a>
            </div>
          </div>
        ))}
      </div>

      {/* Active Config Summary */}
      <div
        className="C"
        style={{
          borderColor: P.color,
          background: P.color + '12',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ color: P.color, fontSize: 20 }}>{P.icon}</span>
          <div>
            <div style={{ fontWeight: 600, fontSize: 15 }}>
              Active: {P.name}
            </div>
            <div style={{ fontSize: 13, color: 'var(--t2)', marginTop: 2 }}>
              Model: {P.models.find((m) => m.id === model)?.label || model}
              {apiKeys[provider] ? ' · Key configured' : ' · ⚠ Key missing!'}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
