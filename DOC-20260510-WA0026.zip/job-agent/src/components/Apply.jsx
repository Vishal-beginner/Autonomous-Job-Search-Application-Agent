import React, { useState, useRef, useCallback } from 'react';
import { PROVIDERS } from '../utils/constants';
import { callAI, parseJSON } from '../utils/api';

const delay = (ms) => new Promise((r) => setTimeout(r, ms));

function Section({ title, children, defaultOpen = true }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div style={{ marginTop: 14 }}>
      <button
        onClick={() => setOpen(!open)}
        style={{
          background: 'none', border: 'none', color: 'var(--ac)', cursor: 'pointer',
          fontFamily: 'var(--fm)', fontSize: 11, fontWeight: 600, textTransform: 'uppercase',
          letterSpacing: 1, display: 'flex', alignItems: 'center', gap: 6,
        }}
      >
        <span style={{ display: 'inline-block', transform: open ? 'rotate(90deg)' : 'rotate(0deg)', transition: '.15s' }}>
          ▶
        </span>
        {title}
      </button>
      {open && <div style={{ marginTop: 8 }}>{children}</div>}
    </div>
  );
}

export default function Apply({ profile, resume, saved, provider, model, apiKeys, apps, setApps, onPersist }) {
  const [jobUrl, setJobUrl] = useState('');
  const [jobText, setJobText] = useState('');
  const [busy, setBusy] = useState(false);
  const [logs, setLogs] = useState([]);
  const [result, setResult] = useState(null);
  const conRef = useRef(null);

  const P = PROVIDERS[provider];
  const key = apiKeys[provider] || '';

  const log = useCallback((msg, type = 'i') => {
    setLogs((p) => [
      ...p,
      {
        t: new Date().toLocaleTimeString('en-US', {
          hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit',
        }),
        msg,
        type,
      },
    ]);
    setTimeout(() => {
      if (conRef.current) conRef.current.scrollTop = conRef.current.scrollHeight;
    }, 30);
  }, []);

  const copyText = (text) => {
    navigator.clipboard?.writeText(text).catch(() => {});
  };

  const markApplied = (id) => {
    const updated = apps.map((a) =>
      a.id === id ? { ...a, status: 'applied', appliedAt: new Date().toISOString() } : a
    );
    setApps(updated);
    onPersist({ apps: updated });
    if (result?.id === id) setResult({ ...result, status: 'applied', appliedAt: new Date().toISOString() });
  };

  const runAgent = async () => {
    if (!jobText.trim()) return;
    if (!saved) { log('Save your profile first', 'e'); return; }
    if (!key) { log(`${P.name} API key required — go to Settings`, 'e'); return; }

    setBusy(true);
    setLogs([]);
    setResult(null);
    log(`Agent started — ${P.name} ${P.models.find((m) => m.id === model)?.label}`, 'i');

    try {
      // ── Step 1: Extract job details + match ──
      log('Extracting job details & matching profile...', 'i');
      await delay(300);

      const extractPrompt = `You are a career analysis assistant. Analyze this job description and candidate profile.

JOB DESCRIPTION:
"""
${jobText.trim().slice(0, 4000)}
"""
${jobUrl ? `\nJob URL: ${jobUrl.trim()}` : ''}

CANDIDATE PROFILE:
Name: ${profile.fullName}
Email: ${profile.email}
Summary: ${profile.summary || 'Not provided'}
LinkedIn: ${profile.linkedin || 'N/A'}
GitHub: ${profile.github || 'N/A'}
LeetCode: ${profile.leetcode || 'N/A'}
Resume highlights: ${resume.slice(0, 1500) || 'Not provided'}

Return ONLY valid JSON (no markdown fences, no preamble):
{
  "title": "exact job title from the posting",
  "company": "exact company name",
  "location": "job location or Remote",
  "type": "Full-time/Part-time/Contract/Internship",
  "salary": "salary range if mentioned, else null",
  "keyRequirements": ["requirement 1", "requirement 2", "requirement 3", "requirement 4", "requirement 5"],
  "matchScore": 0,
  "matchedSkills": ["skill the candidate has that matches"],
  "missingSkills": ["skill the job wants but candidate lacks"],
  "strengthSummary": "1-2 sentence summary of why the candidate is a good fit",
  "gapSummary": "1-2 sentence summary of gaps to address"
}`;

      const extractText = await callAI(provider, model, key, extractPrompt);
      const info = parseJSON(extractText);
      if (!info) throw new Error('Could not parse job details. Try pasting a cleaner description.');
      log(`✓ ${info.title} at ${info.company} — ${info.matchScore}% match`, 's');

      // ── Step 2: Generate cover letter ──
      log('Generating tailored cover letter...', 'i');
      await delay(200);

      const coverPrompt = `Write a concise, professional cover letter (200-280 words) for this application.

CANDIDATE: ${profile.fullName}
Email: ${profile.email}
${profile.linkedin ? `LinkedIn: ${profile.linkedin}` : ''}
Summary: ${profile.summary || ''}
Key skills from resume: ${resume.slice(0, 800)}

JOB: ${info.title} at ${info.company}
Location: ${info.location}
Key requirements: ${(info.keyRequirements || []).join(', ')}

INSTRUCTIONS:
- Address it professionally (Dear Hiring Manager)
- Open with genuine interest in the specific role and company
- Highlight 2-3 specific skills/experiences that match requirements
- Mention any relevant profile links naturally
- Close with enthusiasm and call to action
- Keep it authentic, not generic
- Do NOT use markdown formatting, just plain text
- Sign off with the candidate's name`;

      const coverLetter = await callAI(provider, model, key, coverPrompt);
      log('✓ Cover letter generated', 's');

      // ── Step 3: Generate application answers ──
      log('Generating application answers...', 'i');
      await delay(200);

      const answersPrompt = `Generate answers to common job application questions for this role.

CANDIDATE: ${profile.fullName}, ${profile.summary || ''}
Resume: ${resume.slice(0, 600)}
JOB: ${info.title} at ${info.company}
Requirements: ${(info.keyRequirements || []).join(', ')}

Return ONLY valid JSON (no markdown, no backticks):
{
  "whyThisRole": "2-3 sentence answer to 'Why are you interested in this role?'",
  "whyThisCompany": "2-3 sentence answer to 'Why do you want to work at this company?'",
  "relevantExperience": "3-4 sentence answer to 'Describe your relevant experience'",
  "biggestStrength": "2-3 sentence answer about a key strength relevant to this role",
  "availableStart": "I am available to start immediately / with two weeks notice."
}`;

      const answersText = await callAI(provider, model, key, answersPrompt);
      const answers = parseJSON(answersText) || {};
      log('✓ Application answers generated', 's');

      // ── Build result ──
      const appRecord = {
        id: Date.now().toString(),
        url: jobUrl.trim() || null,
        status: 'ready',
        title: info.title,
        company: info.company,
        location: info.location,
        type: info.type,
        salary: info.salary,
        keyRequirements: info.keyRequirements || [],
        matchScore: info.matchScore,
        matchedSkills: info.matchedSkills || [],
        missingSkills: info.missingSkills || [],
        strengthSummary: info.strengthSummary,
        gapSummary: info.gapSummary,
        coverLetter: coverLetter.replace(/```/g, '').trim(),
        answers,
        provider,
        model,
        createdAt: new Date().toISOString(),
        appliedAt: null,
      };

      setResult(appRecord);
      const newApps = [appRecord, ...apps];
      setApps(newApps);
      onPersist({ apps: newApps });
      log('✓ All materials ready — review below and apply!', 's');
    } catch (err) {
      log('Error: ' + (err.message || 'Unknown error'), 'e');
    } finally {
      setBusy(false);
    }
  };

  const canRun = saved && jobText.trim() && key && !busy;

  return (
    <>
      {!saved && (
        <div className="C" style={{ borderColor: 'var(--wn)' }}>
          <p style={{ color: 'var(--wn)', fontSize: 13 }}>⚠ Save your profile first.</p>
        </div>
      )}
      {!key && (
        <div className="C" style={{ borderColor: 'var(--er)' }}>
          <p style={{ color: 'var(--er)', fontSize: 13 }}>🔑 {P.name} API key required. Go to Settings.</p>
        </div>
      )}

      {/* Input */}
      <div className="C">
        <div className="Ch">
          <div className="ic">📋</div>
          <h2>Job Description</h2>
        </div>
        <p style={{ color: 'var(--t2)', fontSize: 12.5, marginBottom: 12, lineHeight: 1.5 }}>
          Open the job posting in your browser,{' '}
          <strong style={{ color: 'var(--t1)' }}>copy the full description</strong>, and paste it
          below. This is more reliable than crawling since most job sites block automated access.
        </p>
        <div className="F" style={{ marginBottom: 10 }}>
          <label className="L">Job URL (optional — for your records & apply link)</label>
          <input className="I" placeholder="https://linkedin.com/jobs/view/..." value={jobUrl} onChange={(e) => setJobUrl(e.target.value)} disabled={busy} />
        </div>
        <div className="F">
          <label className="L">Job Description (paste the full text) *</label>
          <textarea
            className="I"
            style={{ minHeight: 150 }}
            placeholder={
              'Paste the complete job description here...\n\nInclude: job title, company name, responsibilities, requirements, qualifications, location, salary (if listed), etc.'
            }
            value={jobText}
            onChange={(e) => setJobText(e.target.value)}
            disabled={busy}
          />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 12 }}>
          <button className="B Bp" onClick={runAgent} disabled={!canRun}>
            {busy ? (
              <><span className="spin" /> Analyzing...</>
            ) : (
              <>⚡ Analyze & Generate Materials</>
            )}
          </button>
          <span style={{ fontSize: 11, color: 'var(--t3)', fontFamily: 'var(--fm)' }}>
            {P.icon} {P.name} · {P.models.find((m) => m.id === model)?.label}
          </span>
        </div>

        {/* Console */}
        {logs.length > 0 && (
          <div className="CON" ref={conRef}>
            {logs.map((l, i) => (
              <div className="CL" key={i}>
                <span className="ct">{l.t}</span>
                <span className={l.type === 'i' ? 'ci' : l.type === 's' ? 'cs' : l.type === 'w' ? 'cw' : 'ce'}>
                  {l.msg}
                </span>
              </div>
            ))}
            {busy && (
              <div className="CL">
                <span className="ct pulse">···</span>
                <span className="ci pulse">Working...</span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* ── Results ── */}
      {result && (
        <div className="C" style={{ borderColor: 'rgba(34,211,238,.3)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 8 }}>
            <div>
              <div style={{ fontSize: 17, fontWeight: 700 }}>{result.title}</div>
              <div style={{ fontSize: 13, color: 'var(--t2)', marginTop: 2 }}>
                {result.company} · {result.location} · {result.type}
              </div>
            </div>
            <div style={{ width: 44, height: 44, borderRadius: '50%', background: `conic-gradient(${result.matchScore >= 70 ? 'var(--ok)' : 'var(--wn)'} ${result.matchScore * 3.6}deg, var(--b0) 0deg)`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <div style={{ width: 34, height: 34, borderRadius: '50%', background: 'var(--b2)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, fontFamily: 'var(--fm)' }}>
                {result.matchScore}%
              </div>
            </div>
          </div>

          {result.salary && <div style={{ marginTop: 8, fontSize: 13, color: 'var(--ok)' }}>💰 {result.salary}</div>}

          {/* Skill chips */}
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginTop: 12 }}>
            <div style={{ flex: 1, minWidth: 200 }}>
              <div className="SL">✓ Matched Skills</div>
              <div className="chips">
                {(result.matchedSkills || []).map((s, i) => (
                  <span className="chip" key={i} style={{ borderColor: 'rgba(52,211,153,.2)', color: 'var(--ok)' }}>{s}</span>
                ))}
              </div>
            </div>
            <div style={{ flex: 1, minWidth: 200 }}>
              <div className="SL">△ Gaps to Address</div>
              <div className="chips">
                {(result.missingSkills || []).map((s, i) => (
                  <span className="chip" key={i} style={{ borderColor: 'rgba(251,191,36,.2)', color: 'var(--wn)' }}>{s}</span>
                ))}
              </div>
            </div>
          </div>

          {result.strengthSummary && (
            <div style={{ marginTop: 10, fontSize: 13, color: 'var(--t2)', lineHeight: 1.5 }}>
              <strong style={{ color: 'var(--ok)' }}>Strengths:</strong> {result.strengthSummary}
            </div>
          )}
          {result.gapSummary && (
            <div style={{ marginTop: 4, fontSize: 13, color: 'var(--t2)', lineHeight: 1.5 }}>
              <strong style={{ color: 'var(--wn)' }}>Gaps:</strong> {result.gapSummary}
            </div>
          )}

          {/* Cover Letter */}
          <Section title="Cover Letter">
            <div className="GEN">
              <pre>{result.coverLetter}</pre>
              <button className="B Bs Bsm copy-btn" onClick={() => copyText(result.coverLetter)}>Copy</button>
            </div>
          </Section>

          {/* Answers */}
          {result.answers && Object.keys(result.answers).length > 0 && (
            <Section title="Application Answers">
              {[
                ['whyThisRole', 'Why are you interested in this role?'],
                ['whyThisCompany', `Why do you want to work at ${result.company}?`],
                ['relevantExperience', 'Describe your relevant experience'],
                ['biggestStrength', 'What is your biggest strength for this role?'],
                ['availableStart', 'When can you start?'],
              ]
                .filter(([k]) => result.answers[k])
                .map(([k, q]) => (
                  <div key={k} style={{ marginBottom: 10 }}>
                    <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--t1)', marginBottom: 4 }}>{q}</div>
                    <div className="GEN">
                      <pre>{result.answers[k]}</pre>
                      <button className="B Bs Bsm copy-btn" onClick={() => copyText(result.answers[k])}>Copy</button>
                    </div>
                  </div>
                ))}
            </Section>
          )}

          {/* Actions */}
          <div style={{ display: 'flex', gap: 8, marginTop: 16, flexWrap: 'wrap' }}>
            {result.url && (
              <a href={result.url} target="_blank" rel="noopener noreferrer" className="B Bp" style={{ textDecoration: 'none' }}>
                🔗 Open Job & Apply
              </a>
            )}
            {result.status !== 'applied' && (
              <button className="B Bs" onClick={() => markApplied(result.id)}>✓ Mark as Applied</button>
            )}
            {result.status === 'applied' && (
              <span className="SB" style={{ color: 'var(--ok)', background: 'rgba(52,211,153,.1)' }}>✓ Applied</span>
            )}
            <button className="B Bs" onClick={() => { setResult(null); setJobText(''); setJobUrl(''); setLogs([]); }}>
              + New Application
            </button>
          </div>
        </div>
      )}
    </>
  );
}
