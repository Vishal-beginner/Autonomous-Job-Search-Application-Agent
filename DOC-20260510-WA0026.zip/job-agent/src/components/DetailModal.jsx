import React, { useState } from 'react';
import { STATUSES, PROVIDERS } from '../utils/constants';

function Section({ title, children, defaultOpen = true }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div style={{ marginTop: 14 }}>
      <button
        onClick={() => setOpen(!open)}
        style={{
          background: 'none', border: 'none', color: 'var(--ac)', cursor: 'pointer',
          fontFamily: 'var(--fm)', fontSize: 11, fontWeight: 600, textTransform: 'uppercase',
          letterSpacing: 1, display: 'flex', alignItems: 'center', gap: 6,
        }}
      >
        <span style={{ display: 'inline-block', transform: open ? 'rotate(90deg)' : 'rotate(0deg)', transition: '.15s' }}>▶</span>
        {title}
      </button>
      {open && <div style={{ marginTop: 8 }}>{children}</div>}
    </div>
  );
}

export default function DetailModal({ app, onClose, onUpdateStatus, onMarkApplied }) {
  if (!app) return null;

  const prov = PROVIDERS[app.provider];

  const copyText = (text) => {
    navigator.clipboard?.writeText(text).catch(() => {});
  };

  return (
    <div className="MO" onClick={onClose}>
      <div className="MD" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700 }}>{app.title}</div>
            <div style={{ fontSize: 13, color: 'var(--t2)', marginTop: 2 }}>
              {app.company} · {app.location} · {app.type}
            </div>
          </div>
          <button className="B Bs Bsm" onClick={onClose}>✕</button>
        </div>

        {/* Status + Model badges */}
        <div style={{ display: 'flex', gap: 8, marginTop: 12, marginBottom: 12, flexWrap: 'wrap' }}>
          <span className="SB" style={{
            color: STATUSES[app.status]?.color,
            background: STATUSES[app.status]?.color + '18',
          }}>
            {STATUSES[app.status]?.label}
          </span>
          {app.matchScore != null && (
            <span className="SB" style={{
              color: app.matchScore >= 70 ? 'var(--ok)' : 'var(--wn)',
              background: app.matchScore >= 70 ? 'rgba(52,211,153,.1)' : 'rgba(251,191,36,.1)',
            }}>
              🎯 {app.matchScore}% match
            </span>
          )}
          {prov && (
            <span className="SB" style={{ color: prov.color, background: prov.color + '12' }}>
              {prov.icon} {prov.models.find((m) => m.id === app.model)?.label}
            </span>
          )}
        </div>

        {/* Skill chips */}
        {app.matchedSkills?.length > 0 && (
          <div style={{ marginBottom: 10 }}>
            <div className="SL">Matched Skills</div>
            <div className="chips">
              {app.matchedSkills.map((s, i) => (
                <span className="chip" key={i} style={{ borderColor: 'rgba(52,211,153,.2)', color: 'var(--ok)' }}>{s}</span>
              ))}
            </div>
          </div>
        )}

        {app.missingSkills?.length > 0 && (
          <div style={{ marginBottom: 10 }}>
            <div className="SL">Gaps</div>
            <div className="chips">
              {app.missingSkills.map((s, i) => (
                <span className="chip" key={i} style={{ borderColor: 'rgba(251,191,36,.2)', color: 'var(--wn)' }}>{s}</span>
              ))}
            </div>
          </div>
        )}

        {app.strengthSummary && (
          <div style={{ fontSize: 13, color: 'var(--t2)', marginBottom: 6, lineHeight: 1.5 }}>
            <strong style={{ color: 'var(--ok)' }}>Strengths:</strong> {app.strengthSummary}
          </div>
        )}
        {app.gapSummary && (
          <div style={{ fontSize: 13, color: 'var(--t2)', marginBottom: 12, lineHeight: 1.5 }}>
            <strong style={{ color: 'var(--wn)' }}>Gaps:</strong> {app.gapSummary}
          </div>
        )}

        {/* Cover Letter */}
        {app.coverLetter && (
          <Section title="Cover Letter">
            <div className="GEN">
              <pre>{app.coverLetter}</pre>
              <button className="B Bs Bsm copy-btn" onClick={() => copyText(app.coverLetter)}>Copy</button>
            </div>
          </Section>
        )}

        {/* Answers */}
        {app.answers && Object.keys(app.answers).length > 0 && (
          <Section title="Application Answers" defaultOpen={false}>
            {[
              ['whyThisRole', 'Why this role?'],
              ['whyThisCompany', 'Why this company?'],
              ['relevantExperience', 'Relevant experience'],
              ['biggestStrength', 'Key strength'],
              ['availableStart', 'Availability'],
            ]
              .filter(([k]) => app.answers[k])
              .map(([k, q]) => (
                <div key={k} style={{ marginBottom: 8 }}>
                  <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--t1)', marginBottom: 3 }}>{q}</div>
                  <div className="GEN">
                    <pre>{app.answers[k]}</pre>
                    <button className="B Bs Bsm copy-btn" onClick={() => copyText(app.answers[k])}>Copy</button>
                  </div>
                </div>
              ))}
          </Section>
        )}

        {/* Actions */}
        <div style={{ display: 'flex', gap: 8, marginTop: 16, paddingTop: 14, borderTop: '1px solid var(--br)', flexWrap: 'wrap' }}>
          <select
            className="I"
            style={{ width: 'auto' }}
            value={app.status}
            onChange={(e) => onUpdateStatus(app.id, e.target.value)}
          >
            {Object.entries(STATUSES).map(([k, v]) => (
              <option key={k} value={k}>{v.label}</option>
            ))}
          </select>
          {app.url && (
            <a href={app.url} target="_blank" rel="noopener noreferrer" className="B Bp" style={{ textDecoration: 'none' }}>
              🔗 Open & Apply
            </a>
          )}
          {app.status !== 'applied' && (
            <button className="B Bs" onClick={() => onMarkApplied(app.id)}>✓ Mark Applied</button>
          )}
          <button className="B Bs" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
}
