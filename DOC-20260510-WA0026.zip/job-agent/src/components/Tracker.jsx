import React from 'react';
import { STATUSES, PROVIDERS } from '../utils/constants';

export default function Tracker({ apps, setApps, onPersist, onSelect }) {
  const st = {
    total: apps.length,
    ready: apps.filter((a) => a.status === 'ready').length,
    applied: apps.filter((a) => a.status === 'applied').length,
    interview: apps.filter((a) => a.status === 'interview').length,
  };

  const updateStatus = (id, status) => {
    const updated = apps.map((a) => (a.id === id ? { ...a, status } : a));
    setApps(updated);
    onPersist({ apps: updated });
  };

  const deleteApp = (id) => {
    const updated = apps.filter((a) => a.id !== id);
    setApps(updated);
    onPersist({ apps: updated });
  };

  const exportCSV = () => {
    const header = 'Title,Company,Location,Type,Status,Match %,Model,Applied At,URL';
    const rows = apps.map((a) => {
      const prov = PROVIDERS[a.provider];
      const modelLabel = prov?.models.find((m) => m.id === a.model)?.label || '';
      return `"${(a.title || '').replace(/"/g, '""')}","${a.company || ''}","${a.location || ''}","${a.type || ''}","${STATUSES[a.status]?.label || a.status}","${a.matchScore || ''}","${prov?.name || ''} ${modelLabel}","${a.appliedAt || ''}","${a.url || ''}"`;
    });
    const csv = [header, ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `applications-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <>
      {/* Stats Row */}
      <div className="SR">
        {[
          { l: 'Total', v: st.total, c: 'var(--ac)' },
          { l: 'Ready', v: st.ready, c: '#3b82f6' },
          { l: 'Applied', v: st.applied, c: 'var(--ok)' },
          { l: 'Interview', v: st.interview, c: '#06b6d4' },
        ].map((s, i) => (
          <div className="SC" key={i}>
            <div className="v" style={{ color: s.c }}>{s.v}</div>
            <div className="l">{s.l}</div>
          </div>
        ))}
      </div>

      {/* Application List */}
      {apps.length === 0 ? (
        <div className="C" style={{ textAlign: 'center', padding: 40 }}>
          <div style={{ fontSize: 28, marginBottom: 8 }}>📭</div>
          <div style={{ fontWeight: 600, marginBottom: 4 }}>No applications yet</div>
          <div style={{ fontSize: 13, color: 'var(--t2)' }}>
            Go to Apply, paste a job description, and generate your materials.
          </div>
        </div>
      ) : (
        <div className="C" style={{ padding: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <h2 style={{ fontSize: 15, fontWeight: 600 }}>Applications</h2>
            <button className="B Bs Bsm" onClick={exportCSV}>⬇ Export CSV</button>
          </div>

          {apps.map((app) => {
            const prov = PROVIDERS[app.provider];
            return (
              <div className="JC" key={app.id} onClick={() => onSelect(app)}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 14, fontWeight: 600 }}>{app.title}</div>
                    <div style={{ fontSize: 12, color: 'var(--t2)', marginTop: 1 }}>
                      {app.company} · {app.location}
                    </div>
                  </div>
                  <span
                    className="SB"
                    style={{
                      color: STATUSES[app.status]?.color,
                      background: STATUSES[app.status]?.color + '18',
                      flexShrink: 0,
                    }}
                  >
                    {STATUSES[app.status]?.label}
                  </span>
                </div>

                <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginTop: 8 }}>
                  {app.matchScore != null && (
                    <span style={{
                      fontSize: 11,
                      color: app.matchScore >= 70 ? 'var(--ok)' : 'var(--wn)',
                      fontFamily: 'var(--fm)',
                    }}>
                      🎯 {app.matchScore}%
                    </span>
                  )}
                  {prov && (
                    <span style={{ fontSize: 11, color: 'var(--t3)', fontFamily: 'var(--fm)' }}>
                      {prov.icon} {prov.models.find((m) => m.id === app.model)?.label}
                    </span>
                  )}
                  <span style={{ fontSize: 11, color: 'var(--t3)', fontFamily: 'var(--fm)' }}>
                    {new Date(app.createdAt).toLocaleDateString()}
                  </span>
                </div>

                <div
                  style={{ display: 'flex', gap: 6, marginTop: 10, paddingTop: 10, borderTop: '1px solid var(--br)', flexWrap: 'wrap' }}
                  onClick={(e) => e.stopPropagation()}
                >
                  <select
                    className="I"
                    style={{ width: 'auto', padding: '4px 10px', fontSize: 11 }}
                    value={app.status}
                    onChange={(e) => updateStatus(app.id, e.target.value)}
                  >
                    {Object.entries(STATUSES).map(([k, v]) => (
                      <option key={k} value={k}>{v.label}</option>
                    ))}
                  </select>
                  {app.url && (
                    <a
                      href={app.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="B Bs Bsm"
                      onClick={(e) => e.stopPropagation()}
                      style={{ textDecoration: 'none' }}
                    >
                      Open
                    </a>
                  )}
                  <button className="B Bd Bsm" onClick={() => deleteApp(app.id)}>✕</button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </>
  );
}
