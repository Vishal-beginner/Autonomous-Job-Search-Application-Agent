import React, { useState, useEffect, useCallback } from 'react';
import { PROVIDERS, STORAGE_KEY } from './utils/constants';
import { loadData, saveData } from './utils/storage';
import Profile from './components/Profile';
import Settings from './components/Settings';
import Apply from './components/Apply';
import Tracker from './components/Tracker';
import DetailModal from './components/DetailModal';

export default function App() {
  const [tab, setTab] = useState('profile');

  // Profile state
  const [profile, setProfile] = useState({
    fullName: '', email: '', phone: '',
    linkedin: '', github: '', leetcode: '',
    portfolio: '', summary: '',
  });
  const [resume, setResume] = useState('');
  const [saved, setSaved] = useState(false);

  // AI config
  const [provider, setProvider] = useState('claude');
  const [model, setModel] = useState('claude-sonnet-4-20250514');
  const [apiKeys, setApiKeys] = useState({
    claude: '', openai: '', gemini: '', qwen: '',
  });

  // Applications
  const [apps, setApps] = useState([]);
  const [selectedApp, setSelectedApp] = useState(null);

  // ── Load from localStorage on mount ──
  useEffect(() => {
    const data = loadData();
    if (data) {
      if (data.profile) { setProfile(data.profile); setSaved(true); }
      if (data.apps) setApps(data.apps);
      if (data.resume) setResume(data.resume);
      if (data.prov) setProvider(data.prov);
      if (data.model) setModel(data.model);
      if (data.keys) setApiKeys((k) => ({ ...k, ...data.keys }));
    }
  }, []);

  // ── Persist to localStorage ──
  const persist = useCallback(
    (overrides = {}) => {
      const data = {
        profile,
        apps,
        resume,
        prov: provider,
        model,
        keys: apiKeys,
        ...overrides,
      };
      saveData(data);
    },
    [profile, apps, resume, provider, model, apiKeys]
  );

  // ── Profile save ──
  const saveProfile = () => {
    setSaved(true);
    persist({ profile, resume });
  };

  // ── API key management ──
  const setApiKey = (providerId, value) => {
    const newKeys = { ...apiKeys, [providerId]: value };
    setApiKeys(newKeys);
    persist({ keys: newKeys });
  };

  // ── Provider/model changes ──
  const handleSetProvider = (p) => {
    setProvider(p);
    const m = PROVIDERS[p].models[0].id;
    setModel(m);
    persist({ prov: p, model: m });
  };

  const handleSetModel = (m) => {
    setModel(m);
    persist({ model: m });
  };

  // ── Status updates ──
  const updateStatus = (id, status) => {
    const updated = apps.map((a) => (a.id === id ? { ...a, status } : a));
    setApps(updated);
    persist({ apps: updated });
    if (selectedApp?.id === id) setSelectedApp({ ...selectedApp, status });
  };

  const markApplied = (id) => {
    const updated = apps.map((a) =>
      a.id === id ? { ...a, status: 'applied', appliedAt: new Date().toISOString() } : a
    );
    setApps(updated);
    persist({ apps: updated });
    if (selectedApp?.id === id) {
      setSelectedApp({ ...selectedApp, status: 'applied', appliedAt: new Date().toISOString() });
    }
  };

  return (
    <div className="W">
      {/* ── Header ── */}
      <div className="H">
        <div className="H-ico">JA</div>
        <div>
          <h1>Job Application Agent</h1>
          <p>Paste a job description → get tailored materials → apply with confidence</p>
        </div>
      </div>

      {/* ── Tabs ── */}
      <div className="T">
        {[
          { id: 'profile', label: 'Profile', ico: '👤' },
          { id: 'settings', label: 'AI Model', ico: '⚙' },
          { id: 'apply', label: 'Apply', ico: '🚀' },
          { id: 'tracker', label: 'Tracker', ico: '📊' },
        ].map((t) => (
          <button
            key={t.id}
            className={tab === t.id ? 'on' : ''}
            onClick={() => setTab(t.id)}
          >
            <span>{t.ico}</span> {t.label}
            {t.id === 'tracker' && apps.length > 0 && (
              <span className="badge">{apps.length}</span>
            )}
          </button>
        ))}
      </div>

      {/* ── Tab Content ── */}
      {tab === 'profile' && (
        <Profile
          profile={profile}
          setProfile={setProfile}
          resume={resume}
          setResume={setResume}
          saved={saved}
          onSave={saveProfile}
        />
      )}

      {tab === 'settings' && (
        <Settings
          provider={provider}
          setProvider={handleSetProvider}
          model={model}
          setModel={handleSetModel}
          apiKeys={apiKeys}
          setApiKey={setApiKey}
        />
      )}

      {tab === 'apply' && (
        <Apply
          profile={profile}
          resume={resume}
          saved={saved}
          provider={provider}
          model={model}
          apiKeys={apiKeys}
          apps={apps}
          setApps={setApps}
          onPersist={persist}
        />
      )}

      {tab === 'tracker' && (
        <Tracker
          apps={apps}
          setApps={setApps}
          onPersist={persist}
          onSelect={setSelectedApp}
        />
      )}

      {/* ── Detail Modal ── */}
      <DetailModal
        app={selectedApp}
        onClose={() => setSelectedApp(null)}
        onUpdateStatus={updateStatus}
        onMarkApplied={markApplied}
      />
    </div>
  );
}
