/**
 * Multi-Model API Layer
 *
 * Unified interface for calling Claude, OpenAI, Gemini, and Qwen APIs.
 * Each provider handles request/response formatting differently.
 *
 * API keys are read from the keys object passed in at call time.
 * Keys are stored in localStorage by the Settings component.
 */

// ── Main dispatcher ──────────────────────────────────────────────────────────

export async function callAI(provider, model, apiKey, prompt) {
  if (!apiKey) {
    throw new Error(`API key required for ${provider}. Add it in Settings.`);
  }

  switch (provider) {
    case 'claude':
      return callClaude(model, apiKey, prompt);
    case 'openai':
      return callOpenAI(model, apiKey, prompt);
    case 'gemini':
      return callGemini(model, apiKey, prompt);
    case 'qwen':
      return callQwen(model, apiKey, prompt);
    default:
      throw new Error(`Unknown provider: ${provider}`);
  }
}

// ── Claude (Anthropic) ───────────────────────────────────────────────────────

async function callClaude(model, apiKey, prompt) {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify({
      model,
      max_tokens: 2048,
      messages: [{ role: 'user', content: prompt }],
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Claude API error: ${res.status}`);
  }

  const data = await res.json();
  return (data.content || [])
    .filter((c) => c.type === 'text')
    .map((c) => c.text)
    .join('\n');
}

// ── OpenAI (ChatGPT) ────────────────────────────────────────────────────────

async function callOpenAI(model, apiKey, prompt) {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      max_tokens: 2048,
      temperature: 0.3,
      messages: [
        {
          role: 'system',
          content: 'You are a career assistant. Always return valid JSON when asked.',
        },
        { role: 'user', content: prompt },
      ],
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `OpenAI API error: ${res.status}`);
  }

  const data = await res.json();
  return data.choices?.[0]?.message?.content || '';
}

// ── Gemini (Google) ──────────────────────────────────────────────────────────

async function callGemini(model, apiKey, prompt) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: 0.3,
        maxOutputTokens: 2048,
      },
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Gemini API error: ${res.status}`);
  }

  const data = await res.json();
  return data.candidates?.[0]?.content?.parts?.[0]?.text || '';
}

// ── Qwen (DashScope / Alibaba) ──────────────────────────────────────────────

async function callQwen(model, apiKey, prompt) {
  const res = await fetch(
    'https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        input: {
          messages: [
            {
              role: 'system',
              content: 'You are a career assistant. Always return valid JSON when asked.',
            },
            { role: 'user', content: prompt },
          ],
        },
        parameters: {
          max_tokens: 2048,
          temperature: 0.3,
          result_format: 'message',
        },
      }),
    }
  );

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.message || `Qwen API error: ${res.status}`);
  }

  const data = await res.json();
  return data.output?.choices?.[0]?.message?.content || data.output?.text || '';
}

// ── JSON parser helper ───────────────────────────────────────────────────────

export function parseJSON(text) {
  try {
    const cleaned = text.replace(/```json|```/g, '').trim();
    const match = cleaned.match(/\{[\s\S]*\}/);
    if (match) return JSON.parse(match[0]);
  } catch {
    // parsing failed
  }
  return null;
}
