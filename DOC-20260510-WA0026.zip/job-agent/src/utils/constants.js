/* ═══════════════════════════════════════════════════════════════════
   AI Provider Definitions
   ═══════════════════════════════════════════════════════════════════ */

export const PROVIDERS = {
  claude: {
    name: 'Claude',
    color: '#e8a838',
    icon: '◆',
    models: [
      { id: 'claude-sonnet-4-20250514', label: 'Sonnet 4' },
      { id: 'claude-haiku-4-5-20251001', label: 'Haiku 4.5' },
    ],
    needsKey: true,
    placeholder: 'sk-ant-...',
    docs: 'https://console.anthropic.com/settings/keys',
  },
  openai: {
    name: 'OpenAI',
    color: '#74aa9c',
    icon: '●',
    models: [
      { id: 'gpt-4o', label: 'GPT-4o' },
      { id: 'gpt-4o-mini', label: 'GPT-4o Mini' },
    ],
    needsKey: true,
    placeholder: 'sk-...',
    docs: 'https://platform.openai.com/api-keys',
  },
  gemini: {
    name: 'Gemini',
    color: '#4285f4',
    icon: '✦',
    models: [
      { id: 'gemini-2.5-flash', label: '2.5 Flash' },
      { id: 'gemini-2.0-flash', label: '2.0 Flash' },
    ],
    needsKey: true,
    placeholder: 'AIza...',
    docs: 'https://aistudio.google.com/apikey',
  },
  qwen: {
    name: 'Qwen',
    color: '#a855f7',
    icon: '◈',
    models: [
      { id: 'qwen-plus', label: 'Qwen Plus' },
      { id: 'qwen-turbo', label: 'Qwen Turbo' },
    ],
    needsKey: true,
    placeholder: 'sk-...',
    docs: 'https://dashscope.console.aliyun.com',
  },
};

/* ═══════════════════════════════════════════════════════════════════
   Application Status Definitions
   ═══════════════════════════════════════════════════════════════════ */

export const STATUSES = {
  analyzing: { label: 'Analyzing', color: '#f59e0b' },
  ready: { label: 'Materials Ready', color: '#3b82f6' },
  applied: { label: 'Applied', color: '#10b981' },
  interview: { label: 'Interview', color: '#06b6d4' },
  offered: { label: 'Offered', color: '#22c55e' },
  rejected: { label: 'Rejected', color: '#ef4444' },
};

export const STORAGE_KEY = 'job-agent-v3';
