# 🚀 Job Application Agent

AI-powered job application assistant that analyzes job postings, matches your profile, generates tailored cover letters and application answers, and tracks all your applications in one place.

Supports **Claude**, **ChatGPT (OpenAI)**, **Google Gemini**, and **Qwen (DashScope)**.

---

## Quick Start

```bash
# 1. Clone or extract the project
cd job-agent

# 2. Install dependencies
npm install

# 3. Start the dev server
npm run dev
```

The app opens at [http://localhost:3000](http://localhost:3000).

---

## Setup

### Prerequisites

- **Node.js** 18+ and **npm** 9+
- An API key from at least one provider:

| Provider | Get Key | Free Tier |
|----------|---------|-----------|
| **Claude** (Anthropic) | [console.anthropic.com](https://console.anthropic.com/settings/keys) | $5 credit on signup |
| **ChatGPT** (OpenAI) | [platform.openai.com](https://platform.openai.com/api-keys) | Pay-as-you-go |
| **Gemini** (Google) | [aistudio.google.com](https://aistudio.google.com/apikey) | Free tier available |
| **Qwen** (Alibaba) | [dashscope.console.aliyun.com](https://dashscope.console.aliyun.com) | Free tier available |

### Adding API Keys

API keys are entered directly in the app's **Settings** tab. They are stored in your browser's `localStorage` and are only sent to their respective provider's API endpoint.

> **Note:** The Claude API requires the `anthropic-dangerous-direct-browser-access` header for browser-based calls. This is included in the code. For production use, consider proxying API calls through a backend server.

---

## How It Works

### 1. Profile Tab
Fill in your personal details, profile links (LinkedIn, GitHub, LeetCode), and paste your resume text. This information is used to match against job requirements and generate personalized materials.

### 2. Settings Tab
Choose your AI provider and model. Enter your API key. All providers use the same prompting pipeline — you can switch between them freely.

### 3. Apply Tab
1. **Open the job posting** in your browser
2. **Copy the full job description** text
3. **Paste it** into the text area
4. **Optionally add the URL** (for your records and the "Open & Apply" button)
5. Click **Analyze & Generate Materials**

The agent makes 3 API calls:
- **Extract & Match** — parses job title, company, requirements, and calculates a match score against your profile
- **Cover Letter** — generates a tailored cover letter highlighting your relevant experience
- **Application Answers** — pre-writes answers to common questions (why this role, why this company, relevant experience, etc.)

Every generated text block has a **Copy** button so you can paste directly into application forms.

### 4. Tracker Tab
All analyzed jobs are tracked with their status, match score, and the AI model used. You can:
- Update status (Materials Ready → Applied → Interview → Offered/Rejected)
- View full details including cover letter and answers
- Export everything as a CSV file

---

## Architecture

```
job-agent/
├── index.html              # Entry point
├── package.json            # Dependencies
├── vite.config.js          # Vite configuration
├── .env.example            # API key reference
└── src/
    ├── main.jsx            # React root
    ├── App.jsx             # Main app with state management
    ├── components/
    │   ├── Profile.jsx     # Personal info & resume input
    │   ├── Settings.jsx    # Provider picker & API keys
    │   ├── Apply.jsx       # Job analysis & material generation
    │   ├── Tracker.jsx     # Application list & CSV export
    │   └── DetailModal.jsx # Full application detail view
    ├── utils/
    │   ├── api.js          # Multi-model API abstraction layer
    │   ├── constants.js    # Provider & status definitions
    │   └── storage.js      # localStorage persistence
    └── styles/
        └── index.css       # Global styles & design tokens
```

### Multi-Model API Layer (`src/utils/api.js`)

The `callAI()` function provides a unified interface across all providers:

- **Claude**: `POST /v1/messages` with `anthropic-version` header
- **OpenAI**: `POST /v1/chat/completions` with Bearer auth
- **Gemini**: `POST /v1beta/models/{model}:generateContent` with key param
- **Qwen**: `POST /api/v1/services/aigc/text-generation/generation` with Bearer auth

Each provider handles its own request/response format internally.

---

## Why Paste-First Instead of Auto-Crawl?

Most job boards (LinkedIn, Naukri, Greenhouse, Lever) block automated access via:
- `robots.txt` restrictions
- Login walls / authentication requirements
- JavaScript-rendered content
- Rate limiting and bot detection

Pasting the job description gives the AI the **actual content** to work with, every time, on every job board. The URL field is preserved for your records and the "Open & Apply" link.

---

## Production Considerations

For deploying this as a real product:

1. **Backend proxy** — Route API calls through your own server to protect API keys
2. **Database** — Replace localStorage with PostgreSQL/MongoDB for multi-device sync
3. **Authentication** — Add user accounts for personal data security
4. **Rate limiting** — Implement per-user rate limits on API calls
5. **CORS** — Some providers may block direct browser requests; a proxy solves this

---

## Build for Production

```bash
npm run build    # Outputs to dist/
npm run preview  # Preview the production build
```

---

## License

MIT
