import React, { useState, useEffect, useCallback } from 'react';
import { PROVIDERS, DEFAULT_PROFILE } from './utils/constants';
import { loadData, saveData } from './utils/storage';
import Profile from './components/Profile';
import Settings from './components/Settings';
import JobSearch from './components/JobSearch';
import SpeedApply from './components/SpeedApply';
import Tracker from './components/Tracker';
import DetailModal from './components/DetailModal';

export default function App() {
  const [tab, setTab] = useState('profile');
  const [profile, setProfile] = useState({ ...DEFAULT_PROFILE });
  const [resume, setResume] = useState('');
  const [saved, setSaved] = useState(false);

  const [provider, setProvider] = useState('claude');
  const [model, setModel] = useState('claude-sonnet-4-20250514');
  const [apiKeys, setApiKeys] = useState({ claude: '', openai: '', gemini: '', qwen: '' });

  const [jobs, setJobs] = useState([]);
  const [selected, setSelected] = useState([]);
  const [queue, setQueue] = useState([]);
  const [tracker, setTracker] = useState([]);
  const [viewJob, setViewJob] = useState(null);

  // ── Load ──
  useEffect(() => {
    const data = loadData();
    if (data) {
      if (data.profile) { setProfile(data.profile); setSaved(true); }
      if (data.resume) setResume(data.resume);
      if (data.prov) setProvider(data.prov);
      if (data.model) setModel(data.model);
      if (data.keys) setApiKeys((k) => ({ ...k, ...data.keys }));
      if (data.queue) setQueue(data.queue);
      if (data.tracker) setTracker(data.tracker);
    }
  }, []);

  // ── Persist ──
  const persist = useCallback(
    (ov = {}) => {
      saveData({
        profile, resume, prov: provider, model, keys: apiKeys, queue, tracker,
        ...ov,
      });
    },
    [profile, resume, provider, model, apiKeys, queue, tracker]
  );

  const saveProfile = () => { setSaved(true); persist({ profile, resume }); };
  const setApiKey = (id, val) => { const nk = { ...apiKeys, [id]: val }; setApiKeys(nk); persist({ keys: nk }); };
  const handleSetProvider = (p) => { setProvider(p); setModel(PROVIDERS[p].models[0].id); persist({ prov: p, model: PROVIDERS[p].models[0].id }); };
  const handleSetModel = (m) => { setModel(m); persist({ model: m }); };

  const handlePrepared = (newQueue) => {
    setQueue(newQueue);
    persist({ queue: newQueue });
    setTab('queue');
  };

  const handleApplied = (jobId) => {
    const updated = queue.map((j) =>
      j.id === jobId ? { ...j, status: 'applied', appliedAt: new Date().toISOString() } : j
    );
    setQueue(updated);
    const job = updated.find((j) => j.id === jobId);
    if (job) {
      const newTracker = [job, ...tracker.filter((x) => x.id !== jobId)];
      setTracker(newTracker);
      persist({ queue: updated, tracker: newTracker });
    }
  };

  const handleSkipped = (jobId) => {
    const updated = queue.map((j) => j.id === jobId ? { ...j, status: 'skipped' } : j);
    setQueue(updated);
    persist({ queue: updated });
  };

  const totalApplied = [...queue, ...tracker].filter((j) => j.status === 'applied').length;
  const totalReady = queue.filter((j) => j.status === 'ready').length;

  return (
    <div className="W">
      {/* Header */}
      <div className="HDR">
        <div className="HDR-left">
          <div className="HDR-logo">EA</div>
          <div>
            <h1>Easy Apply Agent</h1>
            <div className="HDR-sub">Find → Prepare → Speed-Apply</div>
          </div>
        </div>
        <div className="HDR-stat">
          <div className="HDR-s"><div className="n" style={{ color: 'var(--ac)' }}>{jobs.length}</div><div className="l">Found</div></div>
          <div className="HDR-s"><div className="n" style={{ color: 'var(--vi)' }}>{totalReady}</div><div className="l">Ready</div></div>
          <div className="HDR-s"><div className="n" style={{ color: 'var(--ok)' }}>{totalApplied}</div><div className="l">Applied</div></div>
        </div>
      </div>

      {/* Tabs */}
      <div className="TBS">
        {[
          { id: 'profile', l: '👤 Profile' },
          { id: 'settings', l: '⚙ AI Model' },
          { id: 'search', l: '🔍 Find Jobs', n: jobs.length },
          { id: 'queue', l: '⚡ Speed Apply', n: totalReady },
          { id: 'tracker', l: '📊 Tracker', n: totalApplied },
        ].map((t) => (
          <button key={t.id} className={`TB ${tab === t.id ? 'on' : ''}`} onClick={() => setTab(t.id)}>
            {t.l}
            {t.n > 0 && <span className="bdg">{t.n}</span>}
          </button>
        ))}
      </div>

      {tab === 'profile' && (
        <Profile profile={profile} setProfile={setProfile} resume={resume} setResume={setResume} saved={saved} onSave={saveProfile} />
      )}

      {tab === 'settings' && (
        <Settings provider={provider} setProvider={handleSetProvider} model={model} setModel={handleSetModel} apiKeys={apiKeys} setApiKey={setApiKey} />
      )}

      {tab === 'search' && (
        <JobSearch
          profile={profile} resume={resume} saved={saved}
          provider={provider} model={model} apiKeys={apiKeys}
          jobs={jobs} setJobs={setJobs}
          selected={selected} setSelected={setSelected}
          onPrepared={handlePrepared}
        />
      )}

      {tab === 'queue' && (
        <SpeedApply queue={queue} setQueue={setQueue} onApplied={handleApplied} onSkipped={handleSkipped} />
      )}

      {tab === 'tracker' && (
        <Tracker queue={queue} tracker={tracker} onSelect={setViewJob} />
      )}

      <DetailModal app={viewJob} onClose={() => setViewJob(null)} />
    </div>
  );
}
