import React, { useState } from 'react';
import { STATUSES } from '../utils/constants';

function Sec({ title, children, open: initOpen = true }) {
  const [open, setOpen] = useState(initOpen);
  return (
    <div>
      <button className="ST" onClick={() => setOpen(!open)}>
        <span className="arr" style={{ transform: open ? 'rotate(90deg)' : 'none' }}>▶</span> {title}
      </button>
      {open && <div style={{ marginTop: 8 }}>{children}</div>}
    </div>
  );
}

export default function SpeedApply({ queue, setQueue, onApplied, onSkipped }) {
  const [idx, setIdx] = useState(0);
  const copy = (t) => navigator.clipboard?.writeText(t).catch(() => {});
  const current = queue[idx];
  const readyCount = queue.filter((j) => j.status === 'ready').length;

  if (queue.length === 0) {
    return (
      <div className="C" style={{ textAlign: 'center', padding: 40 }}>
        <div style={{ fontSize: 32, marginBottom: 8 }}>⚡</div>
        <div style={{ fontWeight: 600, marginBottom: 4 }}>No jobs in queue</div>
        <div style={{ fontSize: 13, color: 'var(--t2)' }}>
          Search for jobs, select them, and click "Prepare" to build your speed-apply queue.
        </div>
      </div>
    );
  }

  const handleApplied = () => {
    onApplied(current.id);
    if (idx < queue.length - 1) setIdx(idx + 1);
  };

  const handleSkipped = () => {
    onSkipped(current.id);
    if (idx < queue.length - 1) setIdx(idx + 1);
  };

  return (
    <>
      {/* Navigation */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <button className="B Bs Bsm" onClick={() => setIdx(Math.max(0, idx - 1))} disabled={idx === 0}>
            ← Prev
          </button>
          <span style={{ fontFamily: 'var(--fm)', fontSize: 12, color: 'var(--t2)' }}>
            {idx + 1} / {queue.length} ({readyCount} pending)
          </span>
          <button className="B Bs Bsm" onClick={() => setIdx(Math.min(queue.length - 1, idx + 1))} disabled={idx >= queue.length - 1}>
            Next →
          </button>
        </div>
        <div className="tags">
          {queue.map((j, i) => (
            <button
              key={j.id}
              onClick={() => setIdx(i)}
              style={{
                width: 24, height: 24, borderRadius: '50%', border: 'none', cursor: 'pointer',
                background: j.status === 'applied' ? 'var(--ok)' : j.status === 'skipped' ? 'var(--t3)' : i === idx ? 'var(--ac)' : 'var(--b3)',
                color: (i === idx || j.status === 'applied') ? '#000' : 'var(--t2)',
                fontSize: 10, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}
            >
              {i + 1}
            </button>
          ))}
        </div>
      </div>

      {/* Current job */}
      {current && (
        <div className="QI active slideIn" key={current.id}>
          <div className="QI-top">
            <div>
              <div style={{ fontSize: 17, fontWeight: 700 }}>{current.title}</div>
              <div style={{ fontSize: 13, color: 'var(--t2)', marginTop: 2 }}>
                {current.company} · {current.location}
              </div>
              {current.matchScore != null && (
                <div style={{ marginTop: 4 }}>
                  <span
                    className="tag"
                    style={{
                      color: current.matchScore >= 70 ? 'var(--ok)' : 'var(--wn)',
                      background: current.matchScore >= 70 ? 'var(--okg)' : 'var(--wng)',
                    }}
                  >
                    🎯 {current.matchScore}% match
                  </span>
                </div>
              )}
            </div>
            <span
              className="tag"
              style={{
                color: STATUSES[current.status]?.color,
                background: STATUSES[current.status]?.color + '14',
              }}
            >
              {STATUSES[current.status]?.label}
            </span>
          </div>

          {current.keySkills?.length > 0 && (
            <div style={{ marginBottom: 10 }}>
              <div className="tags">
                {current.keySkills.map((s, i) => (
                  <span key={i} className="tag" style={{ color: 'var(--t2)', background: 'var(--b3)', border: '1px solid var(--br)' }}>
                    {s}
                  </span>
                ))}
              </div>
            </div>
          )}

          {current.materials && (
            <>
              {current.materials.headline && (
                <div style={{ fontSize: 13, color: 'var(--ac)', fontStyle: 'italic', marginBottom: 10 }}>
                  "{current.materials.headline}"
                </div>
              )}

              <Sec title="Cover Letter">
                <div className="GEN">
                  <pre>{current.materials.coverLetter}</pre>
                  <button className="B Bs Bsm cpb" onClick={() => copy(current.materials.coverLetter)}>Copy</button>
                </div>
              </Sec>

              <Sec title="Application Answers" open={false}>
                {[
                  ['whyThisRole', 'Why this role?'],
                  ['whyThisCompany', `Why ${current.company}?`],
                  ['relevantExperience', 'Relevant experience'],
                  ['keyStrength', 'Key strength'],
                ].filter(([k]) => current.materials[k]).map(([k, q]) => (
                  <div key={k} style={{ marginBottom: 8 }}>
                    <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--t1)', marginBottom: 3 }}>{q}</div>
                    <div className="GEN">
                      <pre>{current.materials[k]}</pre>
                      <button className="B Bs Bsm cpb" onClick={() => copy(current.materials[k])}>Copy</button>
                    </div>
                  </div>
                ))}
              </Sec>
            </>
          )}

          {/* Actions */}
          <div style={{ display: 'flex', gap: 8, marginTop: 16, flexWrap: 'wrap' }}>
            {current.url && (
              <a href={current.url} target="_blank" rel="noopener noreferrer" className="B Bp" style={{ textDecoration: 'none' }}>
                🔗 Open & Easy Apply
              </a>
            )}
            {current.status !== 'applied' && (
              <button className="B Bok" onClick={handleApplied}>✓ I Applied</button>
            )}
            {current.status !== 'applied' && current.status !== 'skipped' && (
              <button className="B Bd" onClick={handleSkipped}>Skip</button>
            )}
            {idx < queue.length - 1 && (
              <button className="B Bs" onClick={() => setIdx(idx + 1)}>Next Job →</button>
            )}
          </div>
        </div>
      )}
    </>
  );
}
