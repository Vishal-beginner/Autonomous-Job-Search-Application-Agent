import React, { useState } from 'react';
import { PROVIDERS } from '../utils/constants';

export default function Settings({ provider, setProvider, model, setModel, apiKeys, setApiKey }) {
  const [keyVis, setKeyVis] = useState({});
  const P = PROVIDERS[provider];

  return (
    <>
      <div className="C">
        <div className="CH"><div className="ic ac-bg">🤖</div><h2>AI Provider</h2></div>
        <p className="hint">All providers require an API key in standalone mode. Claude is recommended — it has web search for job discovery.</p>
        <div className="PR">
          {Object.entries(PROVIDERS).map(([id, p]) => (
            <div
              key={id}
              className={`PC ${provider === id ? 'on' : ''}`}
              onClick={() => { setProvider(id); setModel(PROVIDERS[id].models[0].id); }}
            >
              <span style={{ color: p.color, fontSize: 16 }}>{p.icon}</span>
              <span>{p.name}</span>
              {id === 'claude' && <span style={{ fontSize: 9, color: 'var(--ok)', fontFamily: 'var(--fm)' }}>WEB SEARCH</span>}
            </div>
          ))}
        </div>
        <div className="F" style={{ marginTop: 8 }}>
          <label className="L">Model</label>
          <select className="I" value={model} onChange={(e) => setModel(e.target.value)}>
            {P.models.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}
          </select>
        </div>
      </div>

      <div className="C">
        <div className="CH"><div className="ic wn-bg">🔑</div><h2>API Keys</h2></div>
        <p className="hint">Keys are stored in localStorage and only sent to their provider endpoint.</p>
        {Object.entries(PROVIDERS).map(([id, p]) => (
          <div key={id} style={{ marginBottom: 14 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
              <span style={{ color: p.color }}>{p.icon}</span>
              <span style={{ fontWeight: 600, fontSize: 13 }}>{p.name}</span>
              {apiKeys[id] && <span style={{ color: 'var(--ok)', fontSize: 10, fontFamily: 'var(--fm)' }}>✓ SET</span>}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <input
                className="I"
                style={{ flex: 1 }}
                type={keyVis[id] ? 'text' : 'password'}
                placeholder={p.placeholder}
                value={apiKeys[id] || ''}
                onChange={(e) => setApiKey(id, e.target.value)}
              />
              <button className="B Bs Bsm" onClick={() => setKeyVis((v) => ({ ...v, [id]: !v[id] }))}>
                {keyVis[id] ? 'Hide' : 'Show'}
              </button>
              <a href={p.docs} target="_blank" rel="noopener noreferrer" className="B Bs Bsm">Get Key</a>
            </div>
          </div>
        ))}
      </div>

      <div className="C" style={{ borderColor: P.color, background: P.color + '12' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ color: P.color, fontSize: 20 }}>{P.icon}</span>
          <div>
            <div style={{ fontWeight: 600, fontSize: 15 }}>Active: {P.name}</div>
            <div style={{ fontSize: 13, color: 'var(--t2)', marginTop: 2 }}>
              Model: {P.models.find((m) => m.id === model)?.label || model}
              {apiKeys[provider] ? ' · Key configured' : ' · ⚠ Key missing'}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
