import React from 'react';
import { ROLE_PRESETS } from '../utils/constants';

export default function Profile({ profile, setProfile, resume, setResume, saved, onSave }) {
  const up = (f, v) => setProfile((p) => ({ ...p, [f]: v }));

  return (
    <>
      <div className="C">
        <div className="CH">
          <div className="ic ac-bg">👤</div>
          <h2>Your Details</h2>
          {saved && <span className="saved-tag">✓ SAVED</span>}
        </div>
        <div className="G">
          <div className="F"><label className="L">Full Name</label><input className="I" placeholder="Jane Doe" value={profile.fullName} onChange={(e) => up('fullName', e.target.value)} /></div>
          <div className="F"><label className="L">Email</label><input className="I" type="email" placeholder="jane@example.com" value={profile.email} onChange={(e) => up('email', e.target.value)} /></div>
          <div className="F"><label className="L">Phone</label><input className="I" placeholder="+1 555-0000" value={profile.phone} onChange={(e) => up('phone', e.target.value)} /></div>
          <div className="F"><label className="L">LinkedIn Headline</label><input className="I" placeholder="Senior Backend Engineer | AI/ML" value={profile.headline} onChange={(e) => up('headline', e.target.value)} /></div>
          <div className="F"><label className="L">Years of Experience</label><input className="I" placeholder="4" value={profile.yearsExp} onChange={(e) => up('yearsExp', e.target.value)} /></div>
          <div className="F"><label className="L">Current Location</label><input className="I" placeholder="San Francisco, CA" value={profile.location} onChange={(e) => up('location', e.target.value)} /></div>
          <div className="F w"><label className="L">Education</label><input className="I" placeholder="B.Tech CS, BITS Pilani 2020" value={profile.education} onChange={(e) => up('education', e.target.value)} /></div>
          <div className="F w"><label className="L">Key Skills (comma-separated)</label><input className="I" placeholder="Java, Python, Kubernetes, PostgreSQL, Redis, REST APIs" value={profile.skills} onChange={(e) => up('skills', e.target.value)} /></div>
          <div className="F w"><label className="L">Professional Summary</label><textarea className="I" placeholder="Brief summary of experience and goals..." value={profile.summary} onChange={(e) => up('summary', e.target.value)} /></div>
        </div>
      </div>

      <div className="C">
        <div className="CH"><div className="ic ac-bg">🔗</div><h2>Profile Links</h2></div>
        <div className="G">
          <div className="F"><label className="L">LinkedIn</label><input className="I" placeholder="https://linkedin.com/in/you" value={profile.linkedin} onChange={(e) => up('linkedin', e.target.value)} /></div>
          <div className="F"><label className="L">GitHub</label><input className="I" placeholder="https://github.com/you" value={profile.github} onChange={(e) => up('github', e.target.value)} /></div>
          <div className="F"><label className="L">LeetCode</label><input className="I" placeholder="https://leetcode.com/you" value={profile.leetcode} onChange={(e) => up('leetcode', e.target.value)} /></div>
          <div className="F"><label className="L">Portfolio</label><input className="I" placeholder="https://yoursite.dev" value={profile.portfolio} onChange={(e) => up('portfolio', e.target.value)} /></div>
        </div>
      </div>

      <div className="C">
        <div className="CH"><div className="ic vi-bg">🎯</div><h2>Job Preferences</h2></div>
        <div className="G">
          <div className="F w"><label className="L">Target Roles (comma-separated)</label><input className="I" placeholder="Backend Engineer, AI Engineer, Platform Engineer" value={profile.preferredRoles} onChange={(e) => up('preferredRoles', e.target.value)} /></div>
          <div className="F"><label className="L">Preferred Locations</label><input className="I" placeholder="San Francisco, New York, Remote" value={profile.preferredLocations} onChange={(e) => up('preferredLocations', e.target.value)} /></div>
          <div className="F">
            <label className="L" style={{ marginBottom: 4 }}>Open to Remote?</label>
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: 13 }}>
              <input type="checkbox" checked={profile.remote} onChange={(e) => up('remote', e.target.checked)} style={{ width: 16, height: 16, accentColor: 'var(--ac)' }} />
              Yes, include remote roles
            </label>
          </div>
        </div>
        <div style={{ marginTop: 10 }}>
          <div className="L" style={{ marginBottom: 6 }}>Quick Add Roles:</div>
          <div className="tags">
            {ROLE_PRESETS.map((r) => {
              const active = profile.preferredRoles.includes(r);
              return (
                <button
                  key={r}
                  className="B Bsm"
                  style={{
                    background: active ? 'var(--acg)' : 'var(--b3)',
                    color: active ? 'var(--ac)' : 'var(--t2)',
                    border: `1px solid ${active ? 'var(--ac)' : 'var(--br)'}`,
                  }}
                  onClick={() => {
                    const current = profile.preferredRoles.split(',').map((s) => s.trim()).filter(Boolean);
                    const next = current.includes(r) ? current.filter((x) => x !== r) : [...current, r];
                    up('preferredRoles', next.join(', '));
                  }}
                >
                  {r}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="C">
        <div className="CH"><div className="ic ok-bg">📄</div><h2>Resume</h2></div>
        <textarea
          className="I"
          style={{ minHeight: 120 }}
          placeholder={'Paste your resume text...\n\nSkills, experience, projects, education'}
          value={resume}
          onChange={(e) => setResume(e.target.value)}
        />
      </div>

      <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
        <button className="B Bp" onClick={onSave}>✓ Save Profile</button>
      </div>
    </>
  );
}
