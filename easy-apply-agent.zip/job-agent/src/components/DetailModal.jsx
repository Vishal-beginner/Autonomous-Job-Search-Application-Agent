import React, { useState } from 'react';
import { STATUSES } from '../utils/constants';

function Sec({ title, children, open: initOpen = true }) {
  const [open, setOpen] = useState(initOpen);
  return (
    <div>
      <button className="ST" onClick={() => setOpen(!open)}>
        <span className="arr" style={{ transform: open ? 'rotate(90deg)' : 'none' }}>▶</span> {title}
      </button>
      {open && <div style={{ marginTop: 8 }}>{children}</div>}
    </div>
  );
}

export default function DetailModal({ app, onClose }) {
  if (!app) return null;
  const copy = (t) => navigator.clipboard?.writeText(t).catch(() => {});

  return (
    <div className="MO" onClick={onClose}>
      <div className="MD" onClick={(e) => e.stopPropagation()}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <div style={{ fontSize: 17, fontWeight: 700 }}>{app.title}</div>
            <div style={{ fontSize: 13, color: 'var(--t2)', marginTop: 2 }}>
              {app.company} · {app.location}
            </div>
          </div>
          <button className="B Bs Bsm" onClick={onClose}>✕</button>
        </div>

        <div style={{ display: 'flex', gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
          <span className="tag" style={{ color: STATUSES[app.status]?.color, background: (STATUSES[app.status]?.color || '') + '14' }}>
            {STATUSES[app.status]?.label}
          </span>
          {app.matchScore != null && (
            <span className="tag" style={{ color: 'var(--ac)', background: 'var(--acg)' }}>
              🎯 {app.matchScore}%
            </span>
          )}
        </div>

        {app.keySkills?.length > 0 && (
          <div style={{ marginTop: 10 }}>
            <div className="tags">
              {app.keySkills.map((s, i) => (
                <span key={i} className="tag" style={{ color: 'var(--t2)', background: 'var(--b3)', border: '1px solid var(--br)' }}>
                  {s}
                </span>
              ))}
            </div>
          </div>
        )}

        {app.materials?.coverLetter && (
          <Sec title="Cover Letter">
            <div className="GEN">
              <pre>{app.materials.coverLetter}</pre>
              <button className="B Bs Bsm cpb" onClick={() => copy(app.materials.coverLetter)}>Copy</button>
            </div>
          </Sec>
        )}

        {app.materials && (
          <Sec title="Application Answers" open={false}>
            {['whyThisRole', 'whyThisCompany', 'relevantExperience', 'keyStrength']
              .filter((k) => app.materials[k])
              .map((k) => (
                <div key={k} style={{ marginBottom: 6 }}>
                  <div className="GEN">
                    <pre>{app.materials[k]}</pre>
                    <button className="B Bs Bsm cpb" onClick={() => copy(app.materials[k])}>Copy</button>
                  </div>
                </div>
              ))}
          </Sec>
        )}

        <div style={{ display: 'flex', gap: 8, marginTop: 16, borderTop: '1px solid var(--br)', paddingTop: 12 }}>
          {app.url && (
            <a href={app.url} target="_blank" rel="noopener noreferrer" className="B Bp" style={{ textDecoration: 'none' }}>
              🔗 Open Job
            </a>
          )}
          <button className="B Bs" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
}
