import React, { useState, useRef, useCallback } from 'react';
import { PROVIDERS } from '../utils/constants';
import { callAI, parseJSON } from '../utils/api';
import { searchPrompt, scorePrompt, materialsPrompt } from '../utils/prompts';

const delay = (ms) => new Promise((r) => setTimeout(r, ms));

export default function JobSearch({
  profile, resume, saved, provider, model, apiKeys,
  jobs, setJobs, selected, setSelected,
  onPrepared, // callback with prepared queue
}) {
  const [searching, setSearching] = useState(false);
  const [preparing, setPreparing] = useState(false);
  const [logs, setLogs] = useState([]);
  const conRef = useRef(null);
  const P = PROVIDERS[provider];
  const key = apiKeys[provider] || '';

  const log = useCallback((msg, type = 'i') => {
    setLogs((p) => [...p, {
      t: new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      msg, type,
    }]);
    setTimeout(() => { conRef.current && (conRef.current.scrollTop = conRef.current.scrollHeight); }, 30);
  }, []);

  const toggleSelect = (id) => {
    setSelected((p) => p.includes(id) ? p.filter((x) => x !== id) : [...p, id]);
  };

  const selectAll = () => {
    setSelected(selected.length === jobs.length ? [] : jobs.map((j) => j.id));
  };

  // ── Search ──
  const searchJobs = async () => {
    if (!saved || !key) return;
    setSearching(true);
    setJobs([]);
    setSelected([]);
    setLogs([]);
    log('Searching for LinkedIn Easy Apply jobs...', 'i');

    const roles = profile.preferredRoles || 'Backend Engineer, AI Engineer';
    const loc = profile.preferredLocations || profile.location || 'Remote';

    try {
      const useSearch = provider === 'claude'; // only Claude has web search
      log(`Querying ${P.name}${useSearch ? ' with web search' : ''}...`, 'i');
      const result = await callAI(provider, model, key, searchPrompt(roles, loc, profile.remote, profile.yearsExp), useSearch);
      log('Processing results...', 'i');

      let parsed = parseJSON(result);
      if (parsed && !Array.isArray(parsed)) parsed = parsed.jobs || Object.values(parsed)[0];

      if (!Array.isArray(parsed) || parsed.length === 0) {
        log('Retrying with broader search...', 'w');
        const retry = await callAI(provider, model, key,
          `Find 8+ current "${roles}" job openings on LinkedIn with Easy Apply in ${loc}. Return ONLY a JSON array: [{"title":"...","company":"...","location":"...","salary":null,"url":"https://linkedin.com/jobs/...","easyApply":true,"keySkills":["..."],"postedDate":"Recent","experienceLevel":"Mid-Senior"}]`,
          useSearch
        );
        parsed = parseJSON(retry);
        if (parsed && !Array.isArray(parsed)) parsed = parsed.jobs || [];
      }

      if (Array.isArray(parsed) && parsed.length > 0) {
        const enriched = parsed.map((j, i) => ({
          ...j,
          id: Date.now() + '-' + i,
          matchScore: null,
          status: 'found',
        }));
        setJobs(enriched);
        log(`✓ Found ${enriched.length} jobs`, 's');
      } else {
        log('No structured results. Try different search terms or use Claude (has web search).', 'e');
      }
    } catch (err) {
      log('Error: ' + err.message, 'e');
    } finally {
      setSearching(false);
    }
  };

  // ── Score ──
  const scoreJobs = async () => {
    if (jobs.length === 0 || !key) return;
    log('Calculating match scores...', 'i');
    try {
      const result = await callAI(provider, model, key, scorePrompt(profile, resume, jobs));
      const scores = parseJSON(result);
      if (Array.isArray(scores)) {
        setJobs((prev) => prev.map((j, i) => ({ ...j, matchScore: scores[i] || 50 })));
        log('✓ Scores calculated', 's');
      }
    } catch (err) {
      log('Score error: ' + err.message, 'w');
    }
  };

  // ── Prepare materials ──
  const prepareMaterials = async () => {
    const selectedJobs = jobs.filter((j) => selected.includes(j.id));
    if (selectedJobs.length === 0 || !key) return;

    setPreparing(true);
    log(`Preparing materials for ${selectedJobs.length} jobs...`, 'i');
    const queue = [];

    for (let i = 0; i < selectedJobs.length; i++) {
      const job = selectedJobs[i];
      log(`[${i + 1}/${selectedJobs.length}] ${job.title} at ${job.company}`, 'i');

      try {
        const result = await callAI(provider, model, key, materialsPrompt(profile, resume, job));
        const materials = parseJSON(result);

        if (materials) {
          queue.push({
            ...job,
            status: 'ready',
            materials: {
              coverLetter: (materials.coverLetter || '').replace(/```/g, '').trim(),
              whyThisRole: materials.whyThisRole || '',
              whyThisCompany: materials.whyThisCompany || '',
              relevantExperience: materials.relevantExperience || '',
              keyStrength: materials.keyStrength || '',
              matchHighlights: materials.matchHighlights || '',
              headline: materials.headline || '',
            },
            preparedAt: new Date().toISOString(),
          });
          log(`✓ Ready: ${job.company}`, 's');
        } else {
          log(`⚠ Failed: ${job.company}`, 'w');
        }
      } catch (err) {
        log(`Error: ${job.company} - ${err.message}`, 'e');
      }
      await delay(300);
    }

    log(`✓ Done! ${queue.length} jobs ready in your apply queue.`, 's');
    onPrepared(queue);
    setPreparing(false);
  };

  const canSearch = saved && key && !searching && !preparing;
  const canPrepare = selected.length > 0 && key && !preparing && !searching;

  return (
    <>
      {!saved && <div className="C warn"><p style={{ color: 'var(--wn)', fontSize: 13 }}>⚠ Complete and save your profile first.</p></div>}
      {!key && <div className="C err"><p style={{ color: 'var(--er)', fontSize: 13 }}>🔑 {P.name} API key required. Go to Settings.</p></div>}

      <div className="C accent">
        <div className="CH"><div className="ic ac-bg">🔍</div><h2>Find LinkedIn Easy Apply Jobs</h2></div>
        <p className="hint">
          Searches for active <strong style={{ color: 'var(--t1)' }}>LinkedIn Easy Apply</strong> jobs matching your profile.
          Target roles: <span style={{ color: 'var(--ac)', fontFamily: 'var(--fm)', fontSize: 11 }}>{profile.preferredRoles || 'Not set'}</span>
        </p>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <button className="B Bp" onClick={searchJobs} disabled={!canSearch}>
            {searching ? <><span className="spin" /> Searching...</> : <>🔍 Search Jobs</>}
          </button>
          {jobs.length > 0 && <button className="B Bv" onClick={scoreJobs} disabled={!canSearch}>🎯 Score Matches</button>}
          {jobs.length > 0 && (
            <button className="B Bs" onClick={selectAll}>
              {selected.length === jobs.length ? 'Deselect All' : `Select All (${jobs.length})`}
            </button>
          )}
          {canPrepare && (
            <button className="B Bp" onClick={prepareMaterials} disabled={preparing}>
              {preparing ? <><span className="spin" /> Preparing...</> : <>⚡ Prepare {selected.length} Jobs</>}
            </button>
          )}
        </div>

        {logs.length > 0 && (
          <div className="CON" ref={conRef} style={{ marginTop: 10 }}>
            {logs.map((l, i) => (
              <div className="CL" key={i}>
                <span className="ct">{l.t}</span>
                <span className={l.type === 'i' ? 'ci' : l.type === 's' ? 'cs' : l.type === 'w' ? 'cw' : 'ce'}>{l.msg}</span>
              </div>
            ))}
            {(searching || preparing) && (
              <div className="CL"><span className="ct pulse">···</span><span className="ci pulse">Working...</span></div>
            )}
          </div>
        )}
      </div>

      {/* Job results */}
      {jobs.length > 0 && (
        <div className="C" style={{ padding: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <h2 style={{ fontSize: 14, fontWeight: 600 }}>{jobs.length} Jobs Found</h2>
            <span style={{ fontSize: 11, color: 'var(--ac)', fontFamily: 'var(--fm)' }}>{selected.length} selected</span>
          </div>
          {[...jobs]
            .sort((a, b) => (b.matchScore || 0) - (a.matchScore || 0))
            .map((job) => (
              <div
                key={job.id}
                className={`JR ${selected.includes(job.id) ? 'selected' : ''}`}
                onClick={() => toggleSelect(job.id)}
              >
                <div className="check">{selected.includes(job.id) ? '✓' : ''}</div>
                <div className="JR-info">
                  <div className="JR-title">{job.title}</div>
                  <div className="JR-meta">
                    {job.company} · {job.location}
                    {job.salary ? ` · ${job.salary}` : ''}
                    {job.easyApply ? ' · ⚡ Easy Apply' : ''}
                  </div>
                </div>
                {job.matchScore != null && (
                  <div
                    className="JR-score"
                    style={{ color: job.matchScore >= 75 ? 'var(--ok)' : job.matchScore >= 55 ? 'var(--wn)' : 'var(--t3)' }}
                  >
                    {job.matchScore}%
                  </div>
                )}
                <div className="JR-actions" onClick={(e) => e.stopPropagation()}>
                  {job.url && (
                    <a href={job.url} target="_blank" rel="noopener noreferrer" className="B Bs Bsm">
                      View
                    </a>
                  )}
                </div>
              </div>
            ))}
        </div>
      )}
    </>
  );
}
