import React from 'react';
import { STATUSES } from '../utils/constants';

export default function Tracker({ queue, tracker, onSelect }) {
  const all = [...queue, ...tracker].filter((v, i, a) => a.findIndex((x) => x.id === v.id) === i);
  const applied = all.filter((j) => j.status === 'applied').length;
  const interviews = all.filter((j) => j.status === 'interview').length;
  const ready = all.filter((j) => j.status === 'ready').length;

  const exportCSV = () => {
    const h = 'Title,Company,Location,Status,Match %,Applied At,URL';
    const rows = all.map((a) =>
      `"${(a.title || '').replace(/"/g, '""')}","${a.company || ''}","${a.location || ''}","${STATUSES[a.status]?.label || a.status}","${a.matchScore || ''}","${a.appliedAt || ''}","${a.url || ''}"`
    );
    const blob = new Blob([[h, ...rows].join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    Object.assign(document.createElement('a'), {
      href: url,
      download: `easy-apply-${new Date().toISOString().slice(0, 10)}.csv`,
    }).click();
    URL.revokeObjectURL(url);
  };

  return (
    <>
      <div className="SM">
        <div><div className="v" style={{ color: 'var(--ac)' }}>{all.length}</div><div className="l">Total</div></div>
        <div><div className="v" style={{ color: 'var(--vi)' }}>{ready}</div><div className="l">Ready</div></div>
        <div><div className="v" style={{ color: 'var(--ok)' }}>{applied}</div><div className="l">Applied</div></div>
        <div><div className="v" style={{ color: 'var(--wn)' }}>{interviews}</div><div className="l">Interview</div></div>
      </div>

      {all.length === 0 ? (
        <div className="C" style={{ textAlign: 'center', padding: 36 }}>
          <div style={{ fontSize: 28, marginBottom: 8 }}>📊</div>
          <div style={{ fontWeight: 600, fontSize: 14 }}>No applications to track</div>
          <div style={{ fontSize: 13, color: 'var(--t2)', marginTop: 4 }}>Find jobs, prepare materials, and start applying.</div>
        </div>
      ) : (
        <div className="C" style={{ padding: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <h2 style={{ fontSize: 14, fontWeight: 600 }}>All Applications</h2>
            <button className="B Bs Bsm" onClick={exportCSV}>⬇ Export CSV</button>
          </div>
          {all.map((app) => (
            <div key={app.id} className="JR" onClick={() => onSelect(app)}>
              <div className="JR-info">
                <div className="JR-title">{app.title}</div>
                <div className="JR-meta">
                  {app.company} · {app.location} · {app.appliedAt ? new Date(app.appliedAt).toLocaleDateString() : 'Not applied'}
                </div>
              </div>
              <span
                className="tag"
                style={{ color: STATUSES[app.status]?.color, background: (STATUSES[app.status]?.color || '') + '14' }}
              >
                {STATUSES[app.status]?.label}
              </span>
              {app.matchScore != null && (
                <div className="JR-score" style={{ color: app.matchScore >= 70 ? 'var(--ok)' : 'var(--wn)' }}>
                  {app.matchScore}%
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </>
  );
}
