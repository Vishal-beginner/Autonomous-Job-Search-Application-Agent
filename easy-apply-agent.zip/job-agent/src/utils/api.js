/**
 * Multi-Model API Layer
 * Supports Claude, OpenAI, Gemini, and Qwen.
 * All providers require API keys in standalone mode.
 */

export async function callAI(provider, model, apiKey, prompt, useSearch = false) {
  if (!apiKey) throw new Error(`API key required for ${provider}`);

  switch (provider) {
    case 'claude':
      return callClaude(model, apiKey, prompt, useSearch);
    case 'openai':
      return callOpenAI(model, apiKey, prompt);
    case 'gemini':
      return callGemini(model, apiKey, prompt);
    case 'qwen':
      return callQwen(model, apiKey, prompt);
    default:
      throw new Error(`Unknown provider: ${provider}`);
  }
}

async function callClaude(model, apiKey, prompt, useSearch) {
  const body = {
    model,
    max_tokens: 4096,
    messages: [{ role: 'user', content: prompt }],
  };
  if (useSearch) {
    body.tools = [{ type: 'web_search_20250305', name: 'web_search' }];
  }
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Claude ${res.status}`);
  }
  const data = await res.json();
  return (data.content || []).filter((c) => c.type === 'text').map((c) => c.text).join('\n');
}

async function callOpenAI(model, apiKey, prompt) {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      max_tokens: 4096,
      temperature: 0.3,
      messages: [
        { role: 'system', content: 'You are a career assistant. Return valid JSON when asked.' },
        { role: 'user', content: prompt },
      ],
    }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `OpenAI ${res.status}`);
  }
  return (await res.json()).choices?.[0]?.message?.content || '';
}

async function callGemini(model, apiKey, prompt) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.3, maxOutputTokens: 4096 },
    }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Gemini ${res.status}`);
  }
  return (await res.json()).candidates?.[0]?.content?.parts?.[0]?.text || '';
}

async function callQwen(model, apiKey, prompt) {
  const res = await fetch(
    'https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        input: {
          messages: [
            { role: 'system', content: 'You are a career assistant. Return valid JSON when asked.' },
            { role: 'user', content: prompt },
          ],
        },
        parameters: { max_tokens: 4096, temperature: 0.3, result_format: 'message' },
      }),
    }
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.message || `Qwen ${res.status}`);
  }
  const data = await res.json();
  return data.output?.choices?.[0]?.message?.content || data.output?.text || '';
}

export function parseJSON(text) {
  try {
    const cleaned = text.replace(/```json|```/g, '').trim();
    const match = cleaned.match(/\{[\s\S]*\}|\[[\s\S]*\]/);
    if (match) return JSON.parse(match[0]);
  } catch {}
  return null;
}
