export const STORAGE_KEY = 'easy-apply-agent-v2';

export const PROVIDERS = {
  claude: {
    name: 'Claude',
    color: '#e8a838',
    icon: '◆',
    models: [
      { id: 'claude-sonnet-4-20250514', label: 'Sonnet 4' },
      { id: 'claude-haiku-4-5-20251001', label: 'Haiku 4.5' },
    ],
    placeholder: 'sk-ant-...',
    docs: 'https://console.anthropic.com/settings/keys',
  },
  openai: {
    name: 'OpenAI',
    color: '#74aa9c',
    icon: '●',
    models: [
      { id: 'gpt-4o', label: 'GPT-4o' },
      { id: 'gpt-4o-mini', label: 'GPT-4o Mini' },
    ],
    placeholder: 'sk-...',
    docs: 'https://platform.openai.com/api-keys',
  },
  gemini: {
    name: 'Gemini',
    color: '#4285f4',
    icon: '✦',
    models: [
      { id: 'gemini-2.5-flash', label: '2.5 Flash' },
      { id: 'gemini-2.0-flash', label: '2.0 Flash' },
    ],
    placeholder: 'AIza...',
    docs: 'https://aistudio.google.com/apikey',
  },
  qwen: {
    name: 'Qwen',
    color: '#a855f7',
    icon: '◈',
    models: [
      { id: 'qwen-plus', label: 'Qwen Plus' },
      { id: 'qwen-turbo', label: 'Qwen Turbo' },
    ],
    placeholder: 'sk-...',
    docs: 'https://dashscope.console.aliyun.com',
  },
};

export const STATUSES = {
  found: { label: 'Found', color: '#94a3b8' },
  queued: { label: 'In Queue', color: '#a78bfa' },
  ready: { label: 'Materials Ready', color: '#38bdf8' },
  applied: { label: 'Applied', color: '#34d399' },
  interview: { label: 'Interview', color: '#22d3ee' },
  offered: { label: 'Offered', color: '#4ade80' },
  rejected: { label: 'Rejected', color: '#f87171' },
  skipped: { label: 'Skipped', color: '#64748b' },
};

export const ROLE_PRESETS = [
  'Backend Engineer',
  'Backend Developer',
  'Software Engineer Backend',
  'AI/ML Engineer',
  'AI Engineer',
  'Agentic AI Developer',
  'LLM Engineer',
  'Python Backend Developer',
  'Platform Engineer',
  'Data Engineer',
];

export const DEFAULT_PROFILE = {
  fullName: '',
  email: '',
  phone: '',
  headline: '',
  linkedin: '',
  github: '',
  leetcode: '',
  portfolio: '',
  summary: '',
  yearsExp: '',
  education: '',
  location: '',
  skills: '',
  preferredRoles: 'Backend Engineer, AI Engineer',
  preferredLocations: '',
  remote: true,
};
