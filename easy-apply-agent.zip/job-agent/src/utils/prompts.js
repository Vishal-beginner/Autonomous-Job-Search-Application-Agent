/**
 * Prompt Templates
 * Centralized prompts for job search, scoring, and material generation.
 */

export function searchPrompt(roles, location, remote, yearsExp) {
  return `Search LinkedIn for current job openings matching these criteria:
- Roles: ${roles}
- Location: ${location}${remote ? ' or Remote' : ''}
- Experience: ${yearsExp || '3-5'} years
- Filter: LinkedIn "Easy Apply" jobs only
- Focus: Backend engineering, AI/ML, Agentic AI, LLM, Python, distributed systems

Find at least 8-12 real, currently active job postings.

Return ONLY a valid JSON array (no markdown, no backticks):
[
  {
    "title": "exact job title",
    "company": "company name",
    "location": "city or Remote",
    "salary": "salary if visible, else null",
    "url": "https://linkedin.com/jobs/view/JOBID or best URL",
    "easyApply": true,
    "keySkills": ["skill1", "skill2", "skill3"],
    "postedDate": "approximate date or Recent",
    "experienceLevel": "Mid/Senior/etc"
  }
]`;
}

export function scorePrompt(profile, resume, jobs) {
  const jobList = jobs
    .map((j, i) => `${i}. ${j.title} at ${j.company} — Skills: ${(j.keySkills || []).join(', ')}`)
    .join('\n');

  return `Rate how well this candidate matches each job (0-100).

CANDIDATE:
Name: ${profile.fullName}
Experience: ${profile.yearsExp} years
Skills: ${profile.skills}
Summary: ${profile.summary}
Resume: ${resume.slice(0, 800)}

JOBS:
${jobList}

Return ONLY a JSON array of integer scores in the same order (no markdown):
[85, 72, 90, ...]`;
}

export function materialsPrompt(profile, resume, job) {
  return `Generate application materials for this job.

CANDIDATE: ${profile.fullName}, ${profile.email}
Experience: ${profile.yearsExp} years | Skills: ${profile.skills}
Summary: ${profile.summary}
${profile.linkedin ? `LinkedIn: ${profile.linkedin}` : ''}
${profile.github ? `GitHub: ${profile.github}` : ''}
Resume: ${resume.slice(0, 1000)}

JOB: ${job.title} at ${job.company} (${job.location})
Skills needed: ${(job.keySkills || []).join(', ')}

Return ONLY valid JSON (no markdown):
{
  "coverLetter": "Professional cover letter 180-250 words, plain text, no markdown",
  "whyThisRole": "2-3 sentences",
  "whyThisCompany": "2-3 sentences",
  "relevantExperience": "3-4 sentences",
  "keyStrength": "2-3 sentences about most relevant strength",
  "matchHighlights": "2 key match points separated by newline",
  "headline": "One-line pitch for this specific role"
}`;
}
