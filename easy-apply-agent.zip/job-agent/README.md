# ⚡ Easy Apply Agent

AI-powered LinkedIn Easy Apply job finder with batch material generation and speed-apply queue. Supports **Claude**, **ChatGPT**, **Gemini**, and **Qwen**.

---

## Quick Start

```bash
cd easy-apply-agent
npm install
npm run dev
```

Opens at [http://localhost:3000](http://localhost:3000).

---

## How It Works

### Phase 1: Profile (👤)
Fill in your details, profile links, resume, and job preferences. Target roles can be selected from presets (Backend Engineer, AI/ML Engineer, Agentic AI Developer, LLM Engineer, etc.) or typed manually.

### Phase 2: Settings (⚙)
Pick your AI provider and enter your API key. **Claude is recommended** — it's the only provider with built-in web search, which powers the job discovery engine.

| Provider | Web Search | Get Key |
|----------|-----------|---------|
| Claude (recommended) | ✅ Yes | [console.anthropic.com](https://console.anthropic.com/settings/keys) |
| OpenAI | ❌ | [platform.openai.com](https://platform.openai.com/api-keys) |
| Gemini | ❌ | [aistudio.google.com](https://aistudio.google.com/apikey) |
| Qwen | ❌ | [dashscope.console.aliyun.com](https://dashscope.console.aliyun.com) |

### Phase 3: Find Jobs (🔍)
1. Click **Search Jobs** — the agent uses AI (with web search for Claude) to find 8-12 active LinkedIn Easy Apply jobs matching your target roles and location
2. Click **Score Matches** — batch-calculates a match percentage for every job against your profile
3. **Select** which jobs you want to prepare for (checkbox or Select All)
4. Click **Prepare N Jobs** — generates tailored cover letters and application answers for all selected jobs in one batch

### Phase 4: Speed Apply (⚡)
A paginated queue where you flow through each prepared job:
1. Review the generated cover letter and application answers
2. Click **Copy** on any text block
3. Click **Open & Easy Apply** — LinkedIn opens in a new tab
4. Paste your materials into the Easy Apply form (takes ~30 seconds)
5. Click **I Applied** — auto-advances to the next job
6. Or **Skip** to move on

### Phase 5: Tracker (📊)
Dashboard with stats (total, ready, applied, interview) and full application history. Export everything as CSV.

---

## Project Structure

```
easy-apply-agent/
├── index.html
├── package.json
├── vite.config.js
├── .env.example
├── .gitignore
└── src/
    ├── main.jsx
    ├── App.jsx                 # State management & tab routing
    ├── components/
    │   ├── Profile.jsx         # Personal info, links, job preferences
    │   ├── Settings.jsx        # Provider picker & API keys
    │   ├── JobSearch.jsx       # AI job discovery, scoring, batch prep
    │   ├── SpeedApply.jsx      # Paginated apply queue
    │   ├── Tracker.jsx         # Stats & CSV export
    │   └── DetailModal.jsx     # Job detail overlay
    ├── utils/
    │   ├── api.js              # Multi-model API layer (4 providers)
    │   ├── constants.js        # Providers, statuses, role presets
    │   ├── prompts.js          # Centralized prompt templates
    │   └── storage.js          # localStorage persistence
    └── styles/
        └── index.css           # Design system & all styles
```

---

## Why Not Automated Login & Form Submission?

This agent deliberately does NOT automate LinkedIn login or form submission because:

1. **Account safety** — LinkedIn actively detects and permanently bans accounts using automation bots. Their security fingerprints browser sessions, tracks click timing, and flags non-human patterns.

2. **Legal risk** — Automated access that circumvents platform terms may violate the Computer Fraud and Abuse Act (CFAA) and similar laws in other jurisdictions.

3. **Credential security** — Storing login passwords in a web app creates attack surface. Any XSS vulnerability or malicious browser extension could exfiltrate them.

Instead, this agent does the high-effort part (finding jobs, analyzing fit, writing tailored materials) and leaves the low-effort part (clicking Easy Apply and pasting pre-written text) to you. The result: 30 seconds per application instead of 15 minutes, with zero risk to your account.

---

## API Architecture

The `callAI()` function in `src/utils/api.js` provides a unified interface:

- **Claude**: `POST /v1/messages` with `x-api-key` + `anthropic-dangerous-direct-browser-access` header (required for browser-based calls) + optional web search tool
- **OpenAI**: `POST /v1/chat/completions` with Bearer auth
- **Gemini**: `POST /v1beta/models/{model}:generateContent` with key param
- **Qwen**: `POST /api/v1/services/aigc/text-generation/generation` with Bearer auth

For production deployment, proxy all API calls through a backend to protect keys.

---

## Build

```bash
npm run build     # Output in dist/
npm run preview   # Preview production build
```

## License

MIT
